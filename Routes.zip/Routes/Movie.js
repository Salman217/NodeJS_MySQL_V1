const express = require('express');
const MovieRoute = express.Router();
const auth = require('../Auth');
const db = require('../db');


// Add Movie
MovieRoute.post('/insertmovies',auth.authenticateToken, (req, res) => {
    const { name, year, genre, collection, poster } = req.body;
    db.query('INSERT INTO Movies (name, year, genre, collection, poster) VALUES (?, ?, ?, ?, ?)', 
      [name, year, genre, collection, poster], 
      (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send({ message: 'Movie added successfully' });
      });
  });

  // List Movies with filters
  MovieRoute.get('/fetchMovieDetails',auth.authenticateToken, (req, res) => {
    const { keyword, castAndCrewIds } = req.query;
    
    let query = 'SELECT m.*, GROUP_CONCAT(c.name) AS castAndCrew FROM Movies m ' +
                'LEFT JOIN MovieCastCrew mc ON m.id = mc.movie_id ' +
                'LEFT JOIN CastAndCrew c ON mc.cast_and_crew_id = c.id ';
    
    const filters = [];
    if (keyword) {
      filters.push(`m.name LIKE '%${keyword}%'`);
    }
    if (castAndCrewIds) {
      filters.push(`mc.cast_and_crew_id IN (${castAndCrewIds})`);
    }
  
    if (filters.length > 0) {
      query += 'WHERE ' + filters.join(' AND ');
    }
  
    query += ' GROUP BY m.id';
    
    db.query(query, (err, results) => {
      if (err) return res.status(500).send(err);
      res.json(results);
    });
  });
  


  // Report API
  MovieRoute.get('/reports',auth.authenticateToken, (req, res) => {
    const query = `
      SELECT year, name, collection 
      FROM Movies 
      WHERE year IN (SELECT DISTINCT year FROM Movies)
      ORDER BY year, collection DESC
      LIMIT 3
    `;
    db.query(query, (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });

  

  module.exports = MovieRoute;
